﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            //DoubleToken num1 = new DoubleToken(123.45);
            //Console.WriteLine(num1);
            //SymbolToken sym1 = new SymbolToken(SymbolToken.SymbolsEnum.Power);
            //Console.WriteLine("Symbol: {0}, IsOp: {1}, Precedence: {2}, LtAssoc: {3}, RtAssoc: {4}",
            //    sym1, sym1.IsOperator, sym1.Precedence, sym1.IsLeftAssociative, sym1.IsRightAssociative);
            //sym1 = SymbolToken.FromChar('*');
            //Console.WriteLine("Symbol: {0}, IsOp: {1}, Precedence: {2}, LtAssoc: {3}, RtAssoc: {4}",
            //    sym1, sym1.IsOperator, sym1.Precedence, sym1.IsLeftAssociative, sym1.IsRightAssociative);
            //Console.ReadLine();

            //PostfixQueue queue = new PostfixQueue("1 + 2 - 3 ^ 4 * 5 / 10 % 3");
            //Console.WriteLine(queue);
            //queue = new PostfixQueue("1.7*3.4+3.4/12.5");
            //Console.WriteLine(queue);
            //queue = new PostfixQueue("(1 + 4) / 10 + (1.5 * 3) ^ 2");
            //Console.WriteLine(queue);
            //queue = new PostfixQueue("7 / (3 * 2 + 4 - 10)");
            //Console.WriteLine(queue);
            //Console.ReadLine();


            PostfixQueue queue = new PostfixQueue("1 + 2 - 3 ^ 4 * 5 / 10 % 3");
            Console.WriteLine(queue);
            Console.WriteLine(queue.Calculate());

            queue = new PostfixQueue("1.7*3.4+3.4/12.5");
            Console.WriteLine(queue);
            Console.WriteLine(queue.Calculate());

            queue = new PostfixQueue("(1 + 4) / 10 + (1.5 * 3) ^ 2");
            Console.WriteLine(queue);
            Console.WriteLine(queue.Calculate());

            queue = new PostfixQueue("7 / (3 * 2 + 4 - 10)");
            Console.WriteLine(queue);
            Console.WriteLine(queue.Calculate());
        }
    }
}
