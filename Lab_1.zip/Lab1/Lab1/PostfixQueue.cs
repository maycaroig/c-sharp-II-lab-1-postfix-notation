﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class PostfixQueue : Queue<Token>
    {
        public PostfixQueue(string input)
        {
            Tokenize(input);
        }

        public int Tokenize(string input)
        {
            Clear();
            StringBuilder number = new StringBuilder();
            SymbolTokenStack stack = new SymbolTokenStack(); 
            
            // Trim all whitespace
            input = input.Replace(" ", string.Empty);

            foreach (char ch in input)
            {
                if ("0123456789.".Contains(ch))
                {
                    number.Append(ch);
                }
                else if (number.Length > 0)
                {
                    Enqueue(new DoubleToken(double.Parse(number.ToString())));
                    number = new StringBuilder();
                }

                SymbolToken symbol = SymbolToken.FromChar(ch);

                if (symbol.IsOperator)
                {
                    while (stack.Count > 0)
                    {
                        SymbolToken top = stack.Peek();
                        if ((symbol.IsLeftAssociative && (symbol.Precedence <= top.Precedence)) ||
                            (symbol.IsRightAssociative && (symbol.Precedence < top.Precedence)))
                        {
                            Enqueue(stack.Pop());
                        }
                        else
                        {
                            break;
                        }
                    }

                    stack.Push(symbol);
                }
                else if (symbol.Symbol == SymbolToken.SymbolsEnum.LParen)
                {
                    stack.Push(symbol);
                }
                else if (symbol.Symbol == SymbolToken.SymbolsEnum.RParen)
                {
                    bool lParenFound = false;
                    while (stack.Count > 0)
                    {
                        SymbolToken top = stack.Peek();
                        if (top.Symbol == SymbolToken.SymbolsEnum.LParen)
                        {
                            // Pop the left parens and exit the loop 
                            lParenFound = true;
                            stack.Pop();
                            break;
                        }
                        else
                        {
                            Enqueue(stack.Pop());
                        }
                    } 
                    if (!lParenFound)
                    {
                        throw new Exception("Mismatched parentheses");
                    }
                }               
            }
            if (number.Length > 0)
            {
                Enqueue(new DoubleToken(double.Parse(number.ToString())));
                number = new StringBuilder();
            }
            while (stack.Count > 0)
            {
                SymbolToken token = stack.Pop();
                if (token.IsOperator)
                {
                    Enqueue(token); 
                } 
                else 
                { 
                    throw new Exception("Invalid expression");
                } 
            }

            return Count;
        }

        public override string ToString() 
        { 
            StringBuilder sb = new StringBuilder();
            foreach (Token token in this)
            {
              sb.Append(" " + token.ToString());
            }
            
            return sb.ToString();
        }

        public double Calculate()
        {
            Stack<double> calc = new Stack<double>();

            foreach (Token token in this)
            {
                if (token is DoubleToken)
                {
                    calc.Push((token as DoubleToken).Value);
                }
                else if (token is SymbolToken)
                {
                    SymbolToken symbol = token as SymbolToken;

                    if (calc.Count >= 2)                            //added from instructions
                    {                                               //added from instructions

                        double op1 = calc.Pop();
                        double op2 = calc.Pop();
                        switch (symbol.Symbol)
                        {
                            case Lab1.SymbolToken.SymbolsEnum.Add: calc.Push(op2+op1); break;
                            case Lab1.SymbolToken.SymbolsEnum.Subtract: calc.Push(op2-op1); break;
                            case Lab1.SymbolToken.SymbolsEnum.Multiply: calc.Push(op2*op1); break;
                            case Lab1.SymbolToken.SymbolsEnum.Divide: calc.Push(op2/op1); break;
                            case Lab1.SymbolToken.SymbolsEnum.Modulus: calc.Push(op2%op1); break;
                            case Lab1.SymbolToken.SymbolsEnum.Power: calc.Push(Math.Pow(op2,op1)); break;
                            default: calc.Push((token as DoubleToken).Value); break; 
                        }

                    }                                               //added from instructions

                  }
               }

                if (calc.Count == 1)                                //added from instructions
                {                                                   //added from instructions
                    return calc.Pop();
                }                                                  //added from instructions

                throw new Exception("Error calculating result");  //added from instructions

               }
     }
}
