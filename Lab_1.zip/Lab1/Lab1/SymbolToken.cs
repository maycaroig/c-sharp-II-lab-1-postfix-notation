﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
   public class SymbolToken:Token
    {
        public enum SymbolsEnum 
        {
            Unknown = 0,
            Add,
            Subtract,
            Multiply,
            Divide,
            Modulus,
            Power,
            LParen,
            RParen 
        }

        private SymbolsEnum m_Symbol = SymbolsEnum.Unknown;

        public SymbolsEnum Symbol
        { 
            get 
            { 
                return m_Symbol; 
            }
         
            set 
            {
                if (Enum.IsDefined(typeof(SymbolsEnum), value))
                { 
                    m_Symbol = value; 
                }
                else 
                { 
                    throw new Exception("Unknown symbol.");
                }
            }
        }

        public int Precedence
        {
            get
            {
                switch (Symbol)
                {
                    case (SymbolsEnum.Add):
                        return 1;
                        break;
                    case (SymbolsEnum.Subtract):
                        return 1;
                        break;
                    case (SymbolsEnum.Multiply):
                        return 2;
                        break;
                    case (SymbolsEnum.Divide):
                        return 2;
                        break;
                    case (SymbolsEnum.Modulus):
                        return 2;
                        break;
                    case (SymbolsEnum.Power):
                        return 3;
                        break;
                    default:
                        return 0;
                        break;
                }
            }
        }

        public bool IsOperator
        {
            get 
            {
              if(Precedence > 0) 
                return true;
              else
                return false; 
            } 
        }

        public bool IsRightAssociative
        {
            get
            {
                if (Symbol == SymbolsEnum.Power)
                    return true;
                else
                    return false;
            }
        }

        public bool IsLeftAssociative
        {
            get
            {
                if (IsOperator && Symbol != SymbolsEnum.Power)
                    return true;
                else
                    return false;
            }
        }

        public SymbolToken(SymbolsEnum symbol)
        {
            Symbol = symbol;
        }

        public static SymbolToken FromChar(char ch) 
        {
            switch (ch)
            { 
                case '+': return new SymbolToken(SymbolsEnum.Add);
                case '-': return new SymbolToken(SymbolsEnum.Subtract);
                case '*': return new SymbolToken(SymbolsEnum.Multiply);
                case '/': return new SymbolToken(SymbolsEnum.Divide);
                case '%': return new SymbolToken(SymbolsEnum.Modulus);
                case '(': return new SymbolToken(SymbolsEnum.LParen);
                case ')': return new SymbolToken(SymbolsEnum.RParen);
                case '^': return new SymbolToken(SymbolsEnum.Power);
                default : return new SymbolToken(SymbolsEnum.Unknown);
            }
        }

        public override string ToString()
        {
            switch (Symbol)
            {
                case SymbolsEnum.Add: return "+";
                case SymbolsEnum.Subtract: return "-";
                case SymbolsEnum.Multiply: return "*";
                case SymbolsEnum.Divide: return "/";
                case SymbolsEnum.Modulus: return "%";
                case SymbolsEnum.LParen: return "(";
                case SymbolsEnum.RParen: return ")";
                case SymbolsEnum.Power: return "^";
                default: return "";
            }
        }
    }
}
